package com.machamarket.macha_market

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
