import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

/// Macha Market bag logo (blue bag + orange handle + M)
class MachaLogo extends StatelessWidget {
  final double size;
  final bool showText;
  final bool lightText;

  const MachaLogo({
    super.key,
    this.size = 40,
    this.showText = true,
    this.lightText = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: AppTheme.primaryColor,
            borderRadius: BorderRadius.circular(size * 0.22),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Positioned(
                top: size * 0.08,
                child: Container(
                  width: size * 0.45,
                  height: size * 0.18,
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(color: AppTheme.accentColor, width: size * 0.08),
                      left: BorderSide(color: AppTheme.accentColor, width: size * 0.08),
                      right: BorderSide(color: AppTheme.accentColor, width: size * 0.08),
                    ),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(size * 0.2),
                      topRight: Radius.circular(size * 0.2),
                    ),
                  ),
                ),
              ),
              Text(
                'M',
                style: TextStyle(
                  color: AppTheme.accentColor,
                  fontWeight: FontWeight.w900,
                  fontSize: size * 0.42,
                  height: 1,
                ),
              ),
            ],
          ),
        ),
        if (showText) ...[
          SizedBox(width: size * 0.2),
          RichText(
            text: TextSpan(
              style: TextStyle(
                fontSize: size * 0.42,
                fontWeight: FontWeight.w800,
                color: lightText ? Colors.white : AppTheme.navyColor,
              ),
              children: const [
                TextSpan(text: 'Macha '),
                TextSpan(
                  text: 'Market',
                  style: TextStyle(color: AppTheme.accentColor),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
