import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

/// Returns true only for usable remote image URLs (http/https).
/// Filters local paths, empty strings, and invalid Firebase Storage refs.
bool isValidImageUrl(String? url) {
  if (url == null) return false;
  final u = url.trim();
  if (u.isEmpty) return false;
  if (!(u.startsWith('http://') || u.startsWith('https://'))) return false;
  // Reject incomplete Firebase Storage paths that cause object-not-found
  if (u.contains('firebasestorage.googleapis.com') && u.contains('/o/?')) {
    return false;
  }
  return true;
}

String? firstValidImage(List<String>? images) {
  if (images == null || images.isEmpty) return null;
  for (final i in images) {
    if (isValidImageUrl(i)) return i;
  }
  return null;
}

/// Network product image with graceful fallback when missing/deleted.
class ProductImage extends StatelessWidget {
  final String? url;
  final BoxFit fit;
  final double? width;
  final double? height;
  final BorderRadius? borderRadius;
  final Widget? placeholder;

  const ProductImage({
    super.key,
    required this.url,
    this.fit = BoxFit.cover,
    this.width,
    this.height,
    this.borderRadius,
    this.placeholder,
  });

  @override
  Widget build(BuildContext context) {
    final child = !isValidImageUrl(url)
        ? _placeholder()
        : CachedNetworkImage(
            imageUrl: url!,
            fit: fit,
            width: width,
            height: height,
            placeholder: (_, __) => _placeholder(loading: true),
            errorWidget: (_, __, ___) => _placeholder(),
            fadeInDuration: const Duration(milliseconds: 200),
          );

    if (borderRadius != null) {
      return ClipRRect(borderRadius: borderRadius!, child: child);
    }
    return child;
  }

  Widget _placeholder({bool loading = false}) {
    if (placeholder != null) return placeholder!;
    return Container(
      width: width,
      height: height,
      color: Colors.grey.shade100,
      alignment: Alignment.center,
      child: loading
          ? const SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
          : Icon(Icons.image_not_supported_outlined,
              color: Colors.grey.shade400, size: 36),
    );
  }
}
