// ignore_for_file: type=lint
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      default:
        throw UnsupportedError('Unsupported platform');
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyB2JXjad-O9VoZdf1cO_N4YZr0dj3j1UpI',
    appId: '1:863830011184:web:e17c646b23a2ad6e33acf5',
    messagingSenderId: '863830011184',
    projectId: 'macha-market',
    authDomain: 'macha-market.firebaseapp.com',
    storageBucket: 'macha-market.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyB2JXjad-O9VoZdf1cO_N4YZr0dj3j1UpI',
    appId: '1:863830011184:android:e17c646b23a2ad6e33acf5',
    messagingSenderId: '863830011184',
    projectId: 'macha-market',
    storageBucket: 'macha-market.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyB2JXjad-O9VoZdf1cO_N4YZr0dj3j1UpI',
    appId: '1:863830011184:ios:e17c646b23a2ad6e33acf5',
    messagingSenderId: '863830011184',
    projectId: 'macha-market',
    storageBucket: 'macha-market.firebasestorage.app',
    iosBundleId: 'com.machamarket.machaMarket',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyB2JXjad-O9VoZdf1cO_N4YZr0dj3j1UpI',
    appId: '1:863830011184:ios:e17c646b23a2ad6e33acf5',
    messagingSenderId: '863830011184',
    projectId: 'macha-market',
    storageBucket: 'macha-market.firebasestorage.app',
    iosBundleId: 'com.machamarket.machaMarket',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyB2JXjad-O9VoZdf1cO_N4YZr0dj3j1UpI',
    appId: '1:863830011184:web:e17c646b23a2ad6e33acf5',
    messagingSenderId: '863830011184',
    projectId: 'macha-market',
    authDomain: 'macha-market.firebaseapp.com',
    storageBucket: 'macha-market.firebasestorage.app',
  );
}
