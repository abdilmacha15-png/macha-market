import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../core/constants/app_constants.dart';
import '../features/auth/domain/entities/user_entity.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  User? get currentFirebaseUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  Future<UserEntity> signUp({
    required String email,
    required String password,
    required String fullName,
    required String role,
    String? phone,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
    final user = cred.user!;
    await user.updateDisplayName(fullName);

    final entity = UserEntity(
      id: user.uid,
      email: email,
      fullName: fullName,
      phone: phone,
      role: role,
      createdAt: DateTime.now(),
    );

    await _db.collection(AppConstants.usersCollection).doc(user.uid).set({
      'email': email,
      'fullName': fullName,
      'phone': phone,
      'role': role,
      'isActive': true,
      'isVerified': false,
      'createdAt': FieldValue.serverTimestamp(),
    });

    await _db.collection(AppConstants.walletsCollection).doc(user.uid).set({
      'userId': user.uid,
      'balance': 0.0,
      'pendingBalance': 0.0,
      'totalEarned': 0.0,
      'totalWithdrawn': 0.0,
      'totalCommissionPaid': 0.0,
      'updatedAt': FieldValue.serverTimestamp(),
    });

    return entity;
  }

  Future<UserEntity> signIn({
    required String email,
    required String password,
  }) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    return _fetchUser(cred.user!.uid);
  }

  Future<void> signOut() => _auth.signOut();

  Future<void> sendPasswordReset(String email) =>
      _auth.sendPasswordResetEmail(email: email);

  Future<UserEntity?> getCurrentUser() async {
    final u = _auth.currentUser;
    if (u == null) return null;
    return _fetchUser(u.uid);
  }

  Future<UserEntity> _fetchUser(String uid) async {
    final doc =
        await _db.collection(AppConstants.usersCollection).doc(uid).get();
    if (!doc.exists) throw Exception('User profile not found');
    final d = doc.data()!;
    return UserEntity(
      id: doc.id,
      email: d['email'] ?? '',
      fullName: d['fullName'] ?? '',
      phone: d['phone'],
      photoUrl: d['photoUrl'],
      role: d['role'] ?? AppConstants.roleBuyer,
      isActive: d['isActive'] ?? true,
      isVerified: d['isVerified'] ?? false,
      createdAt: (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      shopName: d['shopName'],
      address: d['address'],
    );
  }

  Stream<UserEntity?> userStream() {
    return _auth.authStateChanges().asyncMap((user) async {
      if (user == null) return null;
      try {
        return await _fetchUser(user.uid);
      } catch (_) {
        return null;
      }
    });
  }

  /// Update user role in Firestore (e.g. buyer → seller).
  /// Matches calls: updateUserRole(userId, role, shopName: ...)
  Future<void> updateUserRole(
    String userId,
    String role, {
    String? shopName,
  }) async {
    final data = <String, dynamic>{
      'role': role,
      'updatedAt': FieldValue.serverTimestamp(),
    };
    if (shopName != null && shopName.isNotEmpty) {
      data['shopName'] = shopName;
    }
    await _db.collection(AppConstants.usersCollection).doc(userId).update(data);
  }
}
