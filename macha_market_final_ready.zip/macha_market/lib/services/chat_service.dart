import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants/app_constants.dart';

class ChatService {
  final _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _chats =>
      _db.collection(AppConstants.chatsCollection);

  Future<String> getOrCreateChat({
    required String userA,
    required String userB,
    required String nameA,
    required String nameB,
    String? productId,
  }) async {
    final existing = await _chats
        .where('participants', arrayContains: userA)
        .get();
    for (final doc in existing.docs) {
      final parts = List<String>.from(doc.data()['participants'] ?? []);
      if (parts.contains(userB)) return doc.id;
    }
    final ref = await _chats.add({
      'participants': [userA, userB],
      'participantNames': {userA: nameA, userB: nameB},
      'productId': productId,
      'lastMessage': '',
      'lastMessageAt': FieldValue.serverTimestamp(),
      'unreadCount': {userA: 0, userB: 0},
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> chatsForUser(String uid) {
    return _chats
        .where('participants', arrayContains: uid)
        .orderBy('lastMessageAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> messages(String chatId) {
    return _chats
        .doc(chatId)
        .collection('messages')
        .orderBy('createdAt', descending: false)
        .snapshots();
  }

  Future<void> sendMessage({
    required String chatId,
    required String senderId,
    required String senderName,
    required String text,
  }) async {
    await _chats.doc(chatId).collection('messages').add({
      'senderId': senderId,
      'senderName': senderName,
      'text': text,
      'isRead': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
    await _chats.doc(chatId).update({
      'lastMessage': text,
      'lastMessageAt': FieldValue.serverTimestamp(),
      'lastMessageSenderId': senderId,
    });
  }
}
