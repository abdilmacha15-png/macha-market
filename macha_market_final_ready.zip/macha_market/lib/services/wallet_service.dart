import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants/app_constants.dart';

class WalletService {
  final _db = FirebaseFirestore.instance;

  Stream<DocumentSnapshot<Map<String, dynamic>>> walletStream(String userId) {
    return _db
        .collection(AppConstants.walletsCollection)
        .doc(userId)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> transactions(String userId) {
    return _db
        .collection('transactions')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots();
  }

  Future<Map<String, double>> getBalances(String userId) async {
    final doc =
        await _db.collection(AppConstants.walletsCollection).doc(userId).get();
    if (!doc.exists) {
      return {'balance': 0, 'totalEarned': 0, 'totalWithdrawn': 0};
    }
    final d = doc.data()!;
    return {
      'balance': (d['balance'] as num?)?.toDouble() ?? 0,
      'totalEarned': (d['totalEarned'] as num?)?.toDouble() ?? 0,
      'totalWithdrawn': (d['totalWithdrawn'] as num?)?.toDouble() ?? 0,
    };
  }
}
