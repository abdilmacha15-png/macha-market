import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants/app_constants.dart';
import '../core/utils/commission_helper.dart';

class OrderService {
  final _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _orders =>
      _db.collection(AppConstants.ordersCollection);
  CollectionReference<Map<String, dynamic>> get _wallets =>
      _db.collection(AppConstants.walletsCollection);
  CollectionReference<Map<String, dynamic>> get _commissions =>
      _db.collection('commissions');
  CollectionReference<Map<String, dynamic>> get _transactions =>
      _db.collection('transactions');

  Future<String> createOrder({
    required String buyerId,
    required String buyerName,
    required List<Map<String, dynamic>> items,
    required double subtotal,
    double deliveryFee = 0,
    String? shippingAddress,
    String? paymentMethod,
  }) async {
    final commission = CommissionHelper.calculateCommission(subtotal);
    final sellerAmount = CommissionHelper.calculateSellerPayout(subtotal);
    final total = subtotal + deliveryFee;

    final ref = await _orders.add({
      'buyerId': buyerId,
      'buyerName': buyerName,
      'items': items,
      'subtotal': subtotal,
      'deliveryFee': deliveryFee,
      'commissionAmount': commission,
      'sellerAmount': sellerAmount,
      'total': total,
      'status': 'pending',
      'shippingAddress': shippingAddress,
      'paymentMethod': paymentMethod ?? 'cash_on_delivery',
      'paymentStatus': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> ordersForBuyer(String buyerId) {
    return _orders
        .where('buyerId', isEqualTo: buyerId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  /// Orders that include at least one item from this seller.
  Stream<List<QueryDocumentSnapshot<Map<String, dynamic>>>> ordersForSeller(
      String sellerId) {
    return _orders.orderBy('createdAt', descending: true).snapshots().map(
          (snap) => snap.docs.where((doc) {
            final items = List<Map<String, dynamic>>.from(doc.data()['items'] ?? []);
            return items.any((i) => i['sellerId'] == sellerId);
          }).toList(),
        );
  }

  Future<void> updateStatus(String orderId, String status) async {
    final data = <String, dynamic>{
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    };

    if (status == 'delivered' || status == 'completed') {
      data['deliveredAt'] = FieldValue.serverTimestamp();
      await _creditSellerAndCommission(orderId);
    }

    await _orders.doc(orderId).update(data);
  }

  Future<void> _creditSellerAndCommission(String orderId) async {
    final order = await _orders.doc(orderId).get();
    if (!order.exists) return;
    final d = order.data()!;
    if (d['commissionProcessed'] == true) return;

    final sellerAmount = (d['sellerAmount'] as num?)?.toDouble() ?? 0;
    final commission = (d['commissionAmount'] as num?)?.toDouble() ?? 0;
    final items = List<Map<String, dynamic>>.from(d['items'] ?? []);
    final sellerIds = items.map((e) => e['sellerId'] as String).toSet();

    for (final sid in sellerIds) {
      final walletRef = _wallets.doc(sid);
      await _db.runTransaction((tx) async {
        final w = await tx.get(walletRef);
        if (w.exists) {
          final bal = (w.data()!['balance'] as num?)?.toDouble() ?? 0;
          final earned = (w.data()!['totalEarned'] as num?)?.toDouble() ?? 0;
          tx.update(walletRef, {
            'balance': bal + sellerAmount,
            'totalEarned': earned + sellerAmount,
            'updatedAt': FieldValue.serverTimestamp(),
          });
        }
      });

      await _transactions.add({
        'userId': sid,
        'type': 'order_earning',
        'amount': sellerAmount,
        'orderId': orderId,
        'description': 'Order earning (95%)',
        'createdAt': FieldValue.serverTimestamp(),
      });
    }

    await _commissions.add({
      'orderId': orderId,
      'amount': commission,
      'rate': CommissionHelper.commissionPercent,
      'buyerId': d['buyerId'],
      'createdAt': FieldValue.serverTimestamp(),
    });

    await _orders.doc(orderId).update({'commissionProcessed': true});
  }

  Future<Map<String, dynamic>> sellerOrderStats(String sellerId) async {
    final snap = await _orders.get();
    int count = 0;
    double sales = 0;
    for (final doc in snap.docs) {
      final items = List<Map<String, dynamic>>.from(doc.data()['items'] ?? []);
      if (items.any((i) => i['sellerId'] == sellerId)) {
        count++;
        if (doc.data()['status'] == 'delivered' ||
            doc.data()['status'] == 'completed') {
          sales += (doc.data()['sellerAmount'] as num?)?.toDouble() ?? 0;
        }
      }
    }
    return {'orders': count, 'sales': sales};
  }
}
