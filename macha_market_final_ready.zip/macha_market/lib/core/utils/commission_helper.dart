import '../constants/app_constants.dart';

class CommissionHelper {
  CommissionHelper._();
  static double get commissionPercent => AppConstants.platformCommissionPercent;
  static double calculateCommission(double subtotal) =>
      subtotal * (commissionPercent / 100);
  static double calculateSellerPayout(double subtotal) =>
      subtotal - calculateCommission(subtotal);
}
