import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/register_page.dart';
import '../../features/admin/presentation/pages/admin_dashboard_page.dart';
import '../../features/wallet/presentation/pages/wallet_page.dart';
import '../../shared/pages/home_page.dart';
import '../../shared/pages/seller_page.dart';
import '../../services/providers.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: '/login',
    debugLogDiagnostics: true,
    redirect: (context, state) {
      final loggedIn = authState.valueOrNull != null;
      final loading = authState.isLoading;
      final loc = state.matchedLocation;
      final isAuth = loc == '/login' || loc == '/register';

      if (loading) return null;
      if (!loggedIn && !isAuth) return '/login';
      if (loggedIn && isAuth) {
        final user = authState.valueOrNull!;
        if (user.isSuperAdmin || user.isAdmin) return '/admin';
        if (user.isSeller) return '/seller';
        return '/home';
      }
      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (_, __) => const LoginPage()),
      GoRoute(path: '/register', builder: (_, __) => const RegisterPage()),
      GoRoute(path: '/home', builder: (_, __) => const HomePage()),
      GoRoute(path: '/seller', builder: (_, __) => const SellerPage()),
      GoRoute(path: '/wallet', builder: (_, __) => const WalletPage()),
      GoRoute(path: '/admin', builder: (_, __) => const AdminDashboardPage()),
    ],
  );
});
