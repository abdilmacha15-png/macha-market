class AppConstants {
  AppConstants._();
  static const String appName = 'Macha Market';
  static const double platformCommissionPercent = 5.0;
  static const String currency = 'TZS';
  static const String currencySymbol = 'TSh';
  static const String usersCollection = 'users';
  static const String productsCollection = 'products';
  static const String ordersCollection = 'orders';
  static const String cartsCollection = 'carts';
  static const String walletsCollection = 'wallets';
  static const String chatsCollection = 'chats';
  static const String messagesCollection = 'messages';
  static const String notificationsCollection = 'notifications';
  static const String roleBuyer = 'buyer';
  static const String roleSeller = 'seller';
  static const String roleAdmin = 'admin';
  static const String roleSuperAdmin = 'super_admin';
  static const String orderPending = 'pending';
  static const String orderConfirmed = 'confirmed';
  static const String orderShipped = 'shipped';
  static const String orderDelivered = 'delivered';
  static const String orderCancelled = 'cancelled';
  static const String orderCompleted = 'completed';
}
