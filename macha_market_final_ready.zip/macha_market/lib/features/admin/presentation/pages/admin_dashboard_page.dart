import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../services/providers.dart';

class AdminDashboardPage extends ConsumerWidget {
  const AdminDashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    final isSuper = user?.isSuperAdmin ?? false;

    return Scaffold(
      appBar: AppBar(
        title: Text(isSuper ? 'Super Admin' : 'Admin Dashboard'),
        actions: [
          IconButton(icon: const Icon(Icons.home), onPressed: () => context.go('/home')),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Overview', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          FutureBuilder(
            future: Future.wait([
              FirebaseFirestore.instance.collection(AppConstants.usersCollection).count().get(),
              FirebaseFirestore.instance.collection(AppConstants.productsCollection).count().get(),
              FirebaseFirestore.instance.collection(AppConstants.ordersCollection).count().get(),
            ]),
            builder: (context, snap) {
              final users = snap.hasData ? snap.data![0].count : 0;
              final products = snap.hasData ? snap.data![1].count : 0;
              final orders = snap.hasData ? snap.data![2].count : 0;
              return GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.4,
                children: [
                  _card(context, 'Users', '$users', Icons.people, Colors.blue),
                  _card(context, 'Products', '$products', Icons.inventory_2, Colors.teal),
                  _card(context, 'Orders', '$orders', Icons.receipt_long, Colors.orange),
                  _card(context, 'Commission', '${AppConstants.platformCommissionPercent}%', Icons.percent, Colors.purple),
                ],
              );
            },
          ),
          const SizedBox(height: 24),
          Text('Management', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          ListTile(leading: const Icon(Icons.people), title: const Text('Manage Users'), trailing: const Icon(Icons.chevron_right), onTap: () {}),
          ListTile(leading: const Icon(Icons.inventory), title: const Text('Moderate Products'), trailing: const Icon(Icons.chevron_right), onTap: () {}),
          ListTile(leading: const Icon(Icons.receipt), title: const Text('All Orders'), trailing: const Icon(Icons.chevron_right), onTap: () {}),
          if (isSuper) ...[
            const Divider(),
            Text('Super Admin', style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.bold)),
            ListTile(leading: const Icon(Icons.settings), title: const Text('Commission Settings (5%)'), trailing: const Icon(Icons.chevron_right), onTap: () {}),
          ],
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: () async {
              await ref.read(authServiceProvider).signOut();
              if (context.mounted) context.go('/login');
            },
            icon: const Icon(Icons.logout),
            label: const Text('Sign Out'),
          ),
        ],
      ),
    );
  }

  Widget _card(BuildContext context, String title, String value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 8),
          Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          Text(title, style: TextStyle(color: Colors.grey.shade600)),
        ]),
      ),
    );
  }
}
