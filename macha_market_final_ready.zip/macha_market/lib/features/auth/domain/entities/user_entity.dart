import 'package:equatable/equatable.dart';
import '../../../../core/constants/app_constants.dart';

class UserEntity extends Equatable {
  final String id;
  final String email;
  final String fullName;
  final String? phone;
  final String? photoUrl;
  final String role;
  final bool isActive;
  final bool isVerified;
  final DateTime createdAt;
  final String? shopName;
  final String? address;

  const UserEntity({
    required this.id,
    required this.email,
    required this.fullName,
    this.phone,
    this.photoUrl,
    required this.role,
    this.isActive = true,
    this.isVerified = false,
    required this.createdAt,
    this.shopName,
    this.address,
  });

  bool get isBuyer => role == AppConstants.roleBuyer;
  bool get isSeller => role == AppConstants.roleSeller;
  bool get isAdmin => role == AppConstants.roleAdmin;
  bool get isSuperAdmin => role == AppConstants.roleSuperAdmin;

  @override
  List<Object?> get props => [id, email, fullName, phone, photoUrl, role, isActive, isVerified, createdAt, shopName, address];
}
