import 'package:equatable/equatable.dart';

class ProductEntity extends Equatable {
  final String id;
  final String sellerId;
  final String sellerName;
  final String name;
  final String description;
  final double price;
  final double? discountPrice;
  final int stock;
  final String category;
  final List<String> images;
  final String location;
  final String condition; // new, used, refurbished
  final String status; // active, inactive, pending_review
  final double rating;
  final int reviewCount;
  final bool isActive;
  final DateTime createdAt;
  final DateTime? updatedAt;

  const ProductEntity({
    required this.id,
    required this.sellerId,
    required this.sellerName,
    required this.name,
    required this.description,
    required this.price,
    this.discountPrice,
    required this.stock,
    required this.category,
    this.images = const [],
    this.location = '',
    this.condition = 'new',
    this.status = 'active',
    this.rating = 0,
    this.reviewCount = 0,
    this.isActive = true,
    required this.createdAt,
    this.updatedAt,
  });

  double get effectivePrice => discountPrice ?? price;
  bool get hasDiscount => discountPrice != null && discountPrice! < price;
  bool get inStock => stock > 0;
  double get discountPercent =>
      hasDiscount ? ((price - discountPrice!) / price * 100) : 0;

  ProductEntity copyWith({
    String? name,
    String? description,
    double? price,
    double? discountPrice,
    int? stock,
    String? category,
    List<String>? images,
    String? location,
    String? condition,
    String? status,
    bool? isActive,
  }) {
    return ProductEntity(
      id: id,
      sellerId: sellerId,
      sellerName: sellerName,
      name: name ?? this.name,
      description: description ?? this.description,
      price: price ?? this.price,
      discountPrice: discountPrice ?? this.discountPrice,
      stock: stock ?? this.stock,
      category: category ?? this.category,
      images: images ?? this.images,
      location: location ?? this.location,
      condition: condition ?? this.condition,
      status: status ?? this.status,
      rating: rating,
      reviewCount: reviewCount,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() => {
        'sellerId': sellerId,
        'sellerName': sellerName,
        'name': name,
        'description': description,
        'price': price,
        'discountPrice': discountPrice,
        'stock': stock,
        'category': category,
        'images': images,
        'location': location,
        'condition': condition,
        'status': status,
        'rating': rating,
        'reviewCount': reviewCount,
        'isActive': isActive,
      };

  @override
  List<Object?> get props =>
      [id, sellerId, name, price, stock, category, status, isActive];
}
