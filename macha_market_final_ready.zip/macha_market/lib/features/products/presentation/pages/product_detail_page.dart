import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../services/providers.dart';
import '../../domain/entities/product_entity.dart';

class ProductDetailPage extends ConsumerStatefulWidget {
  final ProductEntity product;
  const ProductDetailPage({super.key, required this.product});

  @override
  ConsumerState<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends ConsumerState<ProductDetailPage> {
  int qty = 1;
  int imageIndex = 0;

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    final images = p.images;
    final img = images.isNotEmpty ? images[imageIndex.clamp(0, images.length - 1)] : null;

    return Scaffold(
      backgroundColor: Colors.white,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 320,
            pinned: true,
            backgroundColor: Colors.white,
            leading: IconButton(
              icon: const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.arrow_back, color: AppTheme.navyColor)),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              IconButton(
                icon: const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.favorite_border, color: AppTheme.navyColor)),
                onPressed: () {},
              ),
              IconButton(
                icon: const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.share_outlined, color: AppTheme.navyColor)),
                onPressed: () {},
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: img != null
                  ? CachedNetworkImage(imageUrl: img, fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: Colors.grey.shade100, child: const Icon(Icons.image_not_supported_outlined, size: 64)))
                  : Container(color: Colors.grey.shade100, child: const Icon(Icons.image, size: 64)),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (images.length > 1) ...[
                    SizedBox(
                      height: 64,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: images.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (_, i) => GestureDetector(
                          onTap: () => setState(() => imageIndex = i),
                          child: Container(
                            width: 64,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: i == imageIndex ? AppTheme.primaryColor : Colors.grey.shade300,
                                width: i == imageIndex ? 2 : 1,
                              ),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: CachedNetworkImage(imageUrl: images[i], fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: Colors.grey.shade200, child: const Icon(Icons.broken_image_outlined))),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],
                  Text(p.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppTheme.navyColor)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.star, color: AppTheme.accentColor, size: 18),
                      Text(
                        ' ${p.rating > 0 ? p.rating.toStringAsFixed(1) : '4.8'}  (${p.reviewCount > 0 ? p.reviewCount : 125} Reviews)',
                        style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: p.inStock ? Colors.green.shade50 : Colors.red.shade50,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          p.inStock ? 'In Stock' : 'Out of Stock',
                          style: TextStyle(
                            color: p.inStock ? Colors.green.shade700 : Colors.red.shade700,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (p.hasDiscount)
                    Text(
                      '${AppConstants.currencySymbol} ${p.price.toStringAsFixed(0)}',
                      style: TextStyle(
                        decoration: TextDecoration.lineThrough,
                        color: Colors.grey.shade500,
                        fontSize: 14,
                      ),
                    ),
                  Text(
                    '${AppConstants.currencySymbol} ${p.effectivePrice.toStringAsFixed(0)}',
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceColor,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: AppTheme.primaryColor.withOpacity(0.15),
                          child: const Icon(Icons.storefront, color: AppTheme.primaryColor, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.sellerName, style: const TextStyle(fontWeight: FontWeight.w700)),
                              if (p.location.isNotEmpty)
                                Text(p.location, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                            ],
                          ),
                        ),
                        OutlinedButton.icon(
                          onPressed: () {},
                          icon: const Icon(Icons.chat_bubble_outline, size: 16),
                          label: const Text('Chat'),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    children: [
                      _chip(Icons.verified_user_outlined, 'Salama 100%'),
                      _chip(Icons.shield_outlined, 'Warranty'),
                      _chip(Icons.verified_outlined, 'Original'),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text('Maelezo', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text(
                    p.description.isEmpty ? 'Hakuna maelezo.' : p.description,
                    style: TextStyle(color: Colors.grey.shade700, height: 1.5),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      const Text('Idadi', style: TextStyle(fontWeight: FontWeight.w600)),
                      const Spacer(),
                      IconButton(
                        onPressed: qty > 1 ? () => setState(() => qty--) : null,
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      Text('$qty', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      IconButton(
                        onPressed: qty < p.stock ? () => setState(() => qty++) : null,
                        icon: const Icon(Icons.add_circle_outline, color: AppTheme.primaryColor),
                      ),
                    ],
                  ),
                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, -2))],
        ),
        child: SafeArea(
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    ref.read(cartProvider.notifier).add(CartItem(
                          productId: p.id,
                          name: p.name,
                          image: img,
                          price: p.effectivePrice,
                          quantity: qty,
                          sellerId: p.sellerId,
                          stock: p.stock,
                        ));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Imeongezwa kwenye cart'),
                      behavior: SnackBarBehavior.floating,
                    ));
                  },
                  icon: const Icon(Icons.shopping_cart_outlined),
                  label: const Text('Ongeza Cart'),
                  style: OutlinedButton.styleFrom(minimumSize: const Size(0, 50)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    ref.read(cartProvider.notifier).add(CartItem(
                          productId: p.id,
                          name: p.name,
                          image: img,
                          price: p.effectivePrice,
                          quantity: qty,
                          sellerId: p.sellerId,
                          stock: p.stock,
                        ));
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.accentColor,
                    minimumSize: const Size(0, 50),
                  ),
                  child: const Text('Nunua Sasa'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _chip(IconData icon, String label) {
    return Chip(
      avatar: Icon(icon, size: 16, color: AppTheme.primaryColor),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      backgroundColor: AppTheme.primaryColor.withOpacity(0.06),
      side: BorderSide.none,
      visualDensity: VisualDensity.compact,
    );
  }
}
