import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../services/providers.dart';

class WalletPage extends ConsumerWidget {
  const WalletPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    if (user == null) {
      return const Scaffold(body: Center(child: Text('Sign in required')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Wallet')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          StreamBuilder(
            stream: ref.watch(walletServiceProvider).walletStream(user.id),
            builder: (context, snap) {
              final d = snap.data?.data();
              final balance = (d?['balance'] as num?)?.toDouble() ?? 0;
              final earned = (d?['totalEarned'] as num?)?.toDouble() ?? 0;
              final withdrawn = (d?['totalWithdrawn'] as num?)?.toDouble() ?? 0;
              return Card(
                color: Theme.of(context).colorScheme.primaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Available Balance'),
                    const SizedBox(height: 8),
                    Text('${AppConstants.currencySymbol} ${balance.toStringAsFixed(0)}',
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),
                    Row(children: [
                      Expanded(child: Text('Earned\n${AppConstants.currencySymbol} ${earned.toStringAsFixed(0)}')),
                      Expanded(child: Text('Withdrawn\n${AppConstants.currencySymbol} ${withdrawn.toStringAsFixed(0)}')),
                    ]),
                  ]),
                ),
              );
            },
          ),
          const SizedBox(height: 16),
          Text('Transactions', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          StreamBuilder(
            stream: ref.watch(walletServiceProvider).transactions(user.id),
            builder: (context, snap) {
              if (!snap.hasData) return const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()));
              final docs = snap.data!.docs;
              if (docs.isEmpty) {
                return const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: Text('No transactions yet')),
                );
              }
              return Column(
                children: docs.map((doc) {
                  final d = doc.data();
                  final amount = (d['amount'] as num?)?.toDouble() ?? 0;
                  return ListTile(
                    leading: const Icon(Icons.swap_vert),
                    title: Text(d['description'] ?? d['type'] ?? 'Transaction'),
                    trailing: Text(
                      '${AppConstants.currencySymbol} ${amount.toStringAsFixed(0)}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  );
                }).toList(),
              );
            },
          ),
          const SizedBox(height: 16),
          Text(
            'Withdrawals and deposits will be connected to a payment provider in a later release. Order earnings credit automatically when an order is marked delivered.',
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }
}
