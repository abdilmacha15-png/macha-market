import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

import '../core/constants/app_constants.dart';
import '../features/products/domain/entities/product_entity.dart';

/// Cloudinary config (unsigned upload preset)
class CloudinaryConfig {
  static const cloudName = 'qijmuww5';
  static const uploadPreset = 'Macha_present';
  static Uri get uploadUri =>
      Uri.parse('https://api.cloudinary.com/v1_1/$cloudName/image/upload');
}

class ProductService {
  final _db = FirebaseFirestore.instance;
  final _uuid = const Uuid();

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(AppConstants.productsCollection);

  /// Buyer product feed — simple query, client-side active filter.
  Stream<List<ProductEntity>> watchActiveProducts() {
    return _col.limit(150).snapshots().map((snap) {
      final list = snap.docs.map(_fromDoc).where((p) {
        if (!p.isActive) return false;
        final s = p.status.toLowerCase();
        return s.isEmpty || s == 'active';
      }).toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    });
  }

  Stream<List<ProductEntity>> watchSellerProducts(String sellerId) {
    return _col
        .where('sellerId', isEqualTo: sellerId)
        .limit(100)
        .snapshots()
        .map((snap) {
      final list = snap.docs.map(_fromDoc).toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    });
  }

  Future<List<ProductEntity>> getProducts({
    String? category,
    String? search,
  }) async {
    final snap = await _col.limit(150).get();
    var list = snap.docs.map(_fromDoc).where((p) {
      if (!p.isActive) return false;
      final s = p.status.toLowerCase();
      return s.isEmpty || s == 'active';
    }).toList();

    if (category != null && category.isNotEmpty && category != 'All') {
      list = list
          .where((p) => p.category.toLowerCase() == category.toLowerCase())
          .toList();
    }
    if (search != null && search.trim().isNotEmpty) {
      final s = search.toLowerCase();
      list = list
          .where((p) =>
              p.name.toLowerCase().contains(s) ||
              p.description.toLowerCase().contains(s) ||
              p.sellerName.toLowerCase().contains(s))
          .toList();
    }
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  Future<ProductEntity?> getById(String id) async {
    final doc = await _col.doc(id).get();
    if (!doc.exists) return null;
    return _fromDoc(doc);
  }

  /// Upload product image to Cloudinary (unsigned preset).
  /// Returns HTTPS secure URL only — never a local path.
  Future<String> uploadProductImage(File file, String sellerId) async {
    if (!await file.exists()) {
      throw Exception('Image file not found on device');
    }
    final bytes = await file.length();
    if (bytes == 0) throw Exception('Image file is empty');
    if (bytes > 10 * 1024 * 1024) {
      throw Exception('Image too large (max 10MB)');
    }

    // Unsigned upload: only file + upload_preset (folder/public_id can require signing)
    final request = http.MultipartRequest('POST', CloudinaryConfig.uploadUri);
    request.fields['upload_preset'] = CloudinaryConfig.uploadPreset;
    request.fields['context'] = 'seller=$sellerId';

    request.files.add(
      await http.MultipartFile.fromPath(
        'file',
        file.path,
        filename: 'product_${_uuid.v4()}.jpg',
      ),
    );

    late http.StreamedResponse streamed;
    try {
      streamed = await request.send().timeout(const Duration(seconds: 45));
    } catch (e) {
      throw Exception(
        'Network error uploading image. Check internet and try again.\n$e',
      );
    }
    final response = await http.Response.fromStream(streamed);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      String detail = response.body;
      try {
        final err = jsonDecode(response.body);
        detail = err['error']?['message']?.toString() ?? response.body;
      } catch (_) {}
      throw Exception(
        'Cloudinary upload failed (${response.statusCode}): $detail\n'
        'Check: preset "${CloudinaryConfig.uploadPreset}" is Unsigned '
        'and cloud name is "${CloudinaryConfig.cloudName}".',
      );
    }

    final body = jsonDecode(response.body) as Map<String, dynamic>;
    final url = (body['secure_url'] ?? body['url']) as String?;
    if (url == null || !url.startsWith('http')) {
      throw Exception('Invalid Cloudinary response: no image URL');
    }
    return url;
  }

  Future<String> createProduct({
    required String sellerId,
    required String sellerName,
    required String name,
    required String description,
    required double price,
    double? discountPrice,
    required int stock,
    required String category,
    List<String> images = const [],
    String location = '',
    String condition = 'new',
  }) async {
    final safeImages =
        images.where((u) => u.startsWith('http://') || u.startsWith('https://')).toList();

    final ref = await _col.add({
      'sellerId': sellerId,
      'sellerName': sellerName,
      'name': name,
      'description': description,
      'price': price,
      'discountPrice': discountPrice,
      'stock': stock,
      'category': category,
      'images': safeImages,
      'location': location,
      'condition': condition,
      'status': 'active',
      'rating': 0.0,
      'reviewCount': 0,
      'isActive': true,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> updateProduct(String id, Map<String, dynamic> data) async {
    if (data.containsKey('images')) {
      final imgs = List<String>.from(data['images'] ?? []);
      data['images'] = imgs
          .where((u) => u.startsWith('http://') || u.startsWith('https://'))
          .toList();
    }
    data['updatedAt'] = FieldValue.serverTimestamp();
    await _col.doc(id).update(data);
  }

  Future<void> deleteProduct(String id) async {
    await _col.doc(id).update({
      'isActive': false,
      'status': 'inactive',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<Map<String, int>> sellerStats(String sellerId) async {
    final snap = await _col.where('sellerId', isEqualTo: sellerId).get();
    final products = snap.docs.map(_fromDoc).toList();
    final active = products.where((p) => p.isActive).length;
    return {'total': products.length, 'active': active};
  }

  ProductEntity _fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    final rawImages = List<String>.from(d['images'] ?? []);
    final images = rawImages
        .where((u) => u.startsWith('http://') || u.startsWith('https://'))
        .toList();

    return ProductEntity(
      id: doc.id,
      sellerId: d['sellerId'] ?? '',
      sellerName: d['sellerName'] ?? '',
      name: d['name'] ?? '',
      description: d['description'] ?? '',
      price: (d['price'] as num?)?.toDouble() ?? 0,
      discountPrice: (d['discountPrice'] as num?)?.toDouble(),
      stock: d['stock'] ?? 0,
      category: d['category'] ?? 'General',
      images: images,
      location: d['location'] ?? '',
      condition: d['condition'] ?? 'new',
      status: d['status'] ?? 'active',
      rating: (d['rating'] as num?)?.toDouble() ?? 0,
      reviewCount: d['reviewCount'] ?? 0,
      isActive: d['isActive'] ?? true,
      createdAt: (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (d['updatedAt'] as Timestamp?)?.toDate(),
    );
  }
}
