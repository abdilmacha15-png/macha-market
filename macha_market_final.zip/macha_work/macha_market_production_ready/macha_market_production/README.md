# Macha Market

Professional Flutter marketplace for Buyers, Sellers, Admins.

## Features
- Firebase Auth (Email/Password)
- Buyer Home: search, categories, product grid, cart, orders, profile
- Seller Dashboard: stats, products CRUD, image upload, orders, wallet
- Product Details: images, price, seller, quantity, add to cart
- Orders with status flow: pending → accepted → processing → shipped → delivered
- 5% platform commission stored in Firestore (`commissions` collection)
- Wallet + transactions
- Admin dashboard
- Role-based routing (buyer / seller / admin / super_admin)

## Package
`com.machamarket.macha_market`

## Setup
```bash
flutter pub get
flutter create . --platforms=android
```

### Firebase Console (required)
1. Authentication → Email/Password → Enable
2. Deploy rules:
   ```bash
   firebase deploy --only firestore:rules,storage,firestore:indexes
   ```
3. Create indexes if the console prompts (or use `firestore.indexes.json`)

## Run / Build
```bash
flutter run
flutter build apk --release
```

## Seller flow
1. Sign in → Profile → Seller Dashboard (auto-upgrades buyer → seller)
2. Add Product (image, name, price, category, stock, location, condition)
3. Product appears on Buyer Home immediately

## Commission
On order status `delivered`:
- Seller wallet credited with 95%
- Record written to `commissions` (5%)
