import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../services/providers.dart';
import '../../domain/entities/product_entity.dart';

class ProductDetailPage extends ConsumerStatefulWidget {
  final ProductEntity product;
  const ProductDetailPage({super.key, required this.product});

  @override
  ConsumerState<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends ConsumerState<ProductDetailPage> {
  int qty = 1;

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    final img = p.images.isNotEmpty ? p.images.first : null;

    return Scaffold(
      appBar: AppBar(title: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: ListView(
        children: [
          AspectRatio(
            aspectRatio: 1.1,
            child: img != null
                ? CachedNetworkImage(imageUrl: img, fit: BoxFit.cover)
                : Container(color: Colors.grey.shade200, child: const Icon(Icons.image, size: 64)),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.name, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (p.hasDiscount) ...[
                Text('${AppConstants.currencySymbol} ${p.price.toStringAsFixed(0)}',
                    style: TextStyle(decoration: TextDecoration.lineThrough, color: Colors.grey.shade500)),
              ],
              Text(
                '${AppConstants.currencySymbol} ${p.effectivePrice.toStringAsFixed(0)}',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary),
              ),
              const SizedBox(height: 12),
              Row(children: [
                const Icon(Icons.storefront, size: 18),
                const SizedBox(width: 6),
                Text(p.sellerName),
                const Spacer(),
                if (p.location.isNotEmpty) ...[
                  const Icon(Icons.location_on_outlined, size: 18),
                  Text(p.location),
                ],
              ]),
              const SizedBox(height: 8),
              Text('Stock: ${p.stock} · ${p.condition} · ${p.category}',
                  style: TextStyle(color: Colors.grey.shade600)),
              const Divider(height: 28),
              Text('Description', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(p.description.isEmpty ? 'No description' : p.description),
              const SizedBox(height: 20),
              Row(children: [
                const Text('Quantity'),
                const Spacer(),
                IconButton(
                  onPressed: qty > 1 ? () => setState(() => qty--) : null,
                  icon: const Icon(Icons.remove_circle_outline),
                ),
                Text('$qty', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                IconButton(
                  onPressed: qty < p.stock ? () => setState(() => qty++) : null,
                  icon: const Icon(Icons.add_circle_outline),
                ),
              ]),
            ]),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () {
                  ref.read(cartProvider.notifier).add(CartItem(
                        productId: p.id,
                        name: p.name,
                        image: img,
                        price: p.effectivePrice,
                        quantity: qty,
                        sellerId: p.sellerId,
                        stock: p.stock,
                      ));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Added to cart'), behavior: SnackBarBehavior.floating),
                  );
                },
                icon: const Icon(Icons.shopping_cart_outlined),
                label: const Text('Add to Cart'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  ref.read(cartProvider.notifier).add(CartItem(
                        productId: p.id,
                        name: p.name,
                        image: img,
                        price: p.effectivePrice,
                        quantity: qty,
                        sellerId: p.sellerId,
                        stock: p.stock,
                      ));
                  context.go('/home'); // cart tab is inside home
                },
                child: const Text('Buy Now'),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
