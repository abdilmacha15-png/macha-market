import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/constants/app_constants.dart';
import '../../features/products/domain/entities/product_entity.dart';
import '../../features/products/presentation/pages/product_detail_page.dart';
import '../../services/providers.dart';

const _categories = ['All', 'Electronics', 'Fashion', 'Home', 'Sports', 'Books', 'Beauty', 'Food', 'General'];

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  int _tab = 0;
  String _category = 'All';
  String _search = '';
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider);
    final cart = ref.watch(cartProvider);

    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          _buildHome(user?.fullName ?? 'Guest'),
          _CartTab(),
          _OrdersTab(),
          _ProfileTab(user: user),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(
            icon: Badge(isLabelVisible: cart.isNotEmpty, label: Text('${cart.length}'), child: const Icon(Icons.shopping_cart_outlined)),
            selectedIcon: const Icon(Icons.shopping_cart),
            label: 'Cart',
          ),
          const NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Orders'),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _buildHome(String name) {
    final productsAsync = ref.watch(productsProvider);

    return CustomScrollView(slivers: [
      SliverAppBar(
        floating: true,
        title: const Text(AppConstants.appName),
        actions: [
          IconButton(
            icon: const Icon(Icons.storefront),
            tooltip: 'Seller Dashboard',
            onPressed: () async {
              final u = ref.read(currentUserProvider);
              if (u != null && u.isBuyer) {
                try {
                  await ref.read(authServiceProvider).updateUserRole(u.id, 'seller', shopName: u.fullName);
                  ref.invalidate(authStateProvider);
                } catch (_) {}
              }
              if (mounted) context.push('/seller');
            },
          ),
        ],
      ),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Hello, $name 👋', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search products...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _search.isEmpty
                    ? null
                    : IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(() { _search = ''; _searchCtrl.clear(); })),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onChanged: (v) => setState(() => _search = v),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: _categories.map((c) {
                  final selected = _category == c;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text(c),
                      selected: selected,
                      onSelected: (_) => setState(() => _category = c),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 12),
            Text('Latest products', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
          ]),
        ),
      ),
      productsAsync.when(
        loading: () => const SliverFillRemaining(child: Center(child: CircularProgressIndicator())),
        error: (e, _) => SliverFillRemaining(
          child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Could not load products'),
            Text('$e', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
            TextButton(onPressed: () => ref.invalidate(productsProvider), child: const Text('Retry')),
          ])),
        ),
        data: (all) {
          var list = all;
          if (_category != 'All') list = list.where((p) => p.category == _category).toList();
          if (_search.isNotEmpty) {
            final s = _search.toLowerCase();
            list = list.where((p) => p.name.toLowerCase().contains(s) || p.sellerName.toLowerCase().contains(s)).toList();
          }
          if (list.isEmpty) {
            return SliverFillRemaining(
              child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.storefront_outlined, size: 72, color: Colors.grey.shade400),
                const SizedBox(height: 12),
                const Text('No products yet'),
                const SizedBox(height: 8),
                Text('Sellers can add products from Seller Dashboard', style: TextStyle(color: Colors.grey.shade600)),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () => context.push('/seller'),
                  icon: const Icon(Icons.add),
                  label: const Text('Become a Seller'),
                ),
              ])),
            );
          }
          return SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.62,
              ),
              delegate: SliverChildBuilderDelegate(
                (context, i) => _ProductCard(product: list[i]),
                childCount: list.length,
              ),
            ),
          );
        },
      ),
      const SliverToBoxAdapter(child: SizedBox(height: 24)),
    ]);
  }
}

class _ProductCard extends ConsumerWidget {
  final ProductEntity product;
  const _ProductCard({required this.product});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final img = product.images.isNotEmpty ? product.images.first : null;
    return Card(
      child: InkWell(
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProductDetailPage(product: product))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Stack(children: [
              Positioned.fill(
                child: img != null
                    ? CachedNetworkImage(imageUrl: img, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.broken_image))
                    : Container(color: Colors.grey.shade100, child: Icon(Icons.image_outlined, color: Colors.grey.shade400, size: 40)),
              ),
              if (product.hasDiscount)
                Positioned(
                  top: 6, left: 6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(6)),
                    child: Text('-${product.discountPercent.toStringAsFixed(0)}%', style: const TextStyle(color: Colors.white, fontSize: 11)),
                  ),
                ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              const SizedBox(height: 2),
              Text(product.sellerName, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
              if (product.location.isNotEmpty)
                Text(product.location, style: TextStyle(fontSize: 10, color: Colors.grey.shade500)),
              const SizedBox(height: 4),
              Row(children: [
                Expanded(
                  child: Text('${AppConstants.currencySymbol} ${product.effectivePrice.toStringAsFixed(0)}',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
                ),
                IconButton(
                  icon: const Icon(Icons.add_shopping_cart, size: 20),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  onPressed: () {
                    ref.read(cartProvider.notifier).add(CartItem(
                          productId: product.id,
                          name: product.name,
                          image: img,
                          price: product.effectivePrice,
                          quantity: 1,
                          sellerId: product.sellerId,
                          stock: product.stock,
                        ));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Added to cart'),
                      duration: Duration(seconds: 1),
                      behavior: SnackBarBehavior.floating,
                    ));
                  },
                ),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _CartTab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cart = ref.watch(cartProvider);
    final subtotal = ref.read(cartProvider.notifier).subtotal;
    const delivery = 3000.0;
    final total = subtotal + (cart.isEmpty ? 0 : delivery);

    return Scaffold(
      appBar: AppBar(title: const Text('My Cart')),
      body: cart.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.shopping_cart_outlined, size: 72, color: Colors.grey.shade400),
              const SizedBox(height: 12),
              const Text('Cart is empty'),
            ]))
          : Column(children: [
              Expanded(
                child: ListView.builder(
                  itemCount: cart.length,
                  itemBuilder: (_, i) {
                    final item = cart[i];
                    return ListTile(
                      leading: item.image != null
                          ? ClipRRect(borderRadius: BorderRadius.circular(8), child: CachedNetworkImage(imageUrl: item.image!, width: 48, height: 48, fit: BoxFit.cover))
                          : const Icon(Icons.image),
                      title: Text(item.name),
                      subtitle: Text('${AppConstants.currencySymbol} ${item.price.toStringAsFixed(0)}'),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () {
                          if (item.quantity <= 1) {
                            ref.read(cartProvider.notifier).remove(item.productId);
                          } else {
                            ref.read(cartProvider.notifier).updateQty(item.productId, item.quantity - 1);
                          }
                        }),
                        Text('${item.quantity}'),
                        IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => ref.read(cartProvider.notifier).updateQty(item.productId, item.quantity + 1)),
                      ]),
                    );
                  },
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(children: [
                    _row('Subtotal', subtotal),
                    _row('Delivery', delivery),
                    const Divider(),
                    _row('Total', total, bold: true),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity, height: 48,
                      child: ElevatedButton(
                        onPressed: () async {
                          final user = ref.read(currentUserProvider);
                          if (user == null) return;
                          final items = cart.map((e) => {
                                'productId': e.productId,
                                'productName': e.name,
                                'unitPrice': e.price,
                                'quantity': e.quantity,
                                'sellerId': e.sellerId,
                              }).toList();
                          try {
                            await ref.read(orderServiceProvider).createOrder(
                                  buyerId: user.id,
                                  buyerName: user.fullName,
                                  items: items,
                                  subtotal: subtotal,
                                  deliveryFee: delivery,
                                );
                            ref.read(cartProvider.notifier).clear();
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: const Text('Order placed successfully'),
                                backgroundColor: Colors.green.shade700,
                              ));
                            }
                          } catch (e) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order failed: $e'), backgroundColor: Colors.red));
                            }
                          }
                        },
                        child: const Text('Checkout'),
                      ),
                    ),
                  ]),
                ),
              ),
            ]),
    );
  }

  Widget _row(String label, double value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
        Text('${AppConstants.currencySymbol} ${value.toStringAsFixed(0)}',
            style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, fontSize: bold ? 18 : 14)),
      ]),
    );
  }
}

class _OrdersTab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('My Orders')),
      body: user == null
          ? const Center(child: Text('Sign in required'))
          : StreamBuilder(
              stream: ref.watch(orderServiceProvider).ordersForBuyer(user.id),
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final docs = snap.data?.docs ?? [];
                if (docs.isEmpty) {
                  return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.receipt_long_outlined, size: 64, color: Colors.grey.shade400),
                    const SizedBox(height: 12),
                    const Text('No orders yet'),
                  ]));
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: docs.length,
                  itemBuilder: (_, i) {
                    final d = docs[i].data();
                    final status = d['status'] ?? 'pending';
                    final total = (d['total'] as num?)?.toDouble() ?? 0;
                    return Card(
                      child: ListTile(
                        title: Text('Order ${docs[i].id.substring(0, 8)}…'),
                        subtitle: Text('Status: $status'),
                        trailing: Text('${AppConstants.currencySymbol} ${total.toStringAsFixed(0)}',
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

class _ProfileTab extends ConsumerWidget {
  final dynamic user;
  const _ProfileTab({this.user});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        ListTile(
          leading: CircleAvatar(
            backgroundColor: Theme.of(context).colorScheme.primary,
            child: Text((user?.fullName?.isNotEmpty == true) ? user.fullName[0].toUpperCase() : 'U',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
          title: Text(user?.fullName ?? 'User'),
          subtitle: Text(user?.email ?? ''),
        ),
        ListTile(leading: const Icon(Icons.badge_outlined), title: const Text('Role'), subtitle: Text((user?.role ?? 'buyer').toString().toUpperCase())),
        ListTile(
          leading: const Icon(Icons.storefront_outlined),
          title: const Text('Seller Dashboard'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () async {
            final u = ref.read(currentUserProvider);
            if (u != null && u.isBuyer) {
              try {
                await ref.read(authServiceProvider).updateUserRole(u.id, 'seller', shopName: u.fullName);
                ref.invalidate(authStateProvider);
              } catch (_) {}
            }
            if (context.mounted) context.push('/seller');
          },
        ),
        ListTile(leading: const Icon(Icons.account_balance_wallet_outlined), title: const Text('Wallet'), trailing: const Icon(Icons.chevron_right), onTap: () => context.push('/wallet')),
        if (user?.isAdmin == true || user?.isSuperAdmin == true)
          ListTile(leading: const Icon(Icons.admin_panel_settings), title: const Text('Admin Dashboard'), trailing: const Icon(Icons.chevron_right), onTap: () => context.push('/admin')),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: const Text('Sign Out', style: TextStyle(color: Colors.red)),
          onTap: () async {
            await ref.read(authServiceProvider).signOut();
            if (context.mounted) context.go('/login');
          },
        ),
      ]),
    );
  }
}
