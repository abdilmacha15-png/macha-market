import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';
import '../core/constants/app_constants.dart';
import '../features/products/domain/entities/product_entity.dart';

class ProductService {
  final _db = FirebaseFirestore.instance;
  final _storage = FirebaseStorage.instance;
  final _uuid = const Uuid();

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection(AppConstants.productsCollection);

  Stream<List<ProductEntity>> watchActiveProducts() {
    return _col
        .where('isActive', isEqualTo: true)
        .where('status', isEqualTo: 'active')
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots()
        .map((s) => s.docs.map(_fromDoc).toList());
  }

  Stream<List<ProductEntity>> watchSellerProducts(String sellerId) {
    return _col
        .where('sellerId', isEqualTo: sellerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map(_fromDoc).toList());
  }

  Future<List<ProductEntity>> getProducts({String? category, String? search}) async {
    Query<Map<String, dynamic>> q =
        _col.where('isActive', isEqualTo: true).where('status', isEqualTo: 'active');
    if (category != null && category.isNotEmpty && category != 'All') {
      q = q.where('category', isEqualTo: category);
    }
    final snap = await q.orderBy('createdAt', descending: true).limit(100).get();
    var list = snap.docs.map(_fromDoc).toList();
    if (search != null && search.trim().isNotEmpty) {
      final s = search.toLowerCase();
      list = list
          .where((p) =>
              p.name.toLowerCase().contains(s) ||
              p.description.toLowerCase().contains(s) ||
              p.sellerName.toLowerCase().contains(s))
          .toList();
    }
    return list;
  }

  Future<ProductEntity?> getById(String id) async {
    final doc = await _col.doc(id).get();
    if (!doc.exists) return null;
    return _fromDoc(doc);
  }

  Future<String> uploadProductImage(File file, String sellerId) async {
    final ext = file.path.split('.').last.toLowerCase();
    final path = 'products/$sellerId/${_uuid.v4()}.$ext';
    final ref = _storage.ref().child(path);
    await ref.putFile(file, SettableMetadata(contentType: 'image/$ext'));
    return ref.getDownloadURL();
  }

  Future<String> createProduct({
    required String sellerId,
    required String sellerName,
    required String name,
    required String description,
    required double price,
    double? discountPrice,
    required int stock,
    required String category,
    List<String> images = const [],
    String location = '',
    String condition = 'new',
  }) async {
    final ref = await _col.add({
      'sellerId': sellerId,
      'sellerName': sellerName,
      'name': name,
      'description': description,
      'price': price,
      'discountPrice': discountPrice,
      'stock': stock,
      'category': category,
      'images': images,
      'location': location,
      'condition': condition,
      'status': 'active',
      'rating': 0.0,
      'reviewCount': 0,
      'isActive': true,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> updateProduct(String id, Map<String, dynamic> data) async {
    data['updatedAt'] = FieldValue.serverTimestamp();
    await _col.doc(id).update(data);
  }

  Future<void> deleteProduct(String id) async {
    await _col.doc(id).update({
      'isActive': false,
      'status': 'inactive',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<Map<String, int>> sellerStats(String sellerId) async {
    final snap = await _col.where('sellerId', isEqualTo: sellerId).get();
    final products = snap.docs.map(_fromDoc).toList();
    final active = products.where((p) => p.isActive).length;
    return {
      'total': products.length,
      'active': active,
    };
  }

  ProductEntity _fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    return ProductEntity(
      id: doc.id,
      sellerId: d['sellerId'] ?? '',
      sellerName: d['sellerName'] ?? '',
      name: d['name'] ?? '',
      description: d['description'] ?? '',
      price: (d['price'] as num?)?.toDouble() ?? 0,
      discountPrice: (d['discountPrice'] as num?)?.toDouble(),
      stock: d['stock'] ?? 0,
      category: d['category'] ?? 'General',
      images: List<String>.from(d['images'] ?? []),
      location: d['location'] ?? '',
      condition: d['condition'] ?? 'new',
      status: d['status'] ?? 'active',
      rating: (d['rating'] as num?)?.toDouble() ?? 0,
      reviewCount: d['reviewCount'] ?? 0,
      isActive: d['isActive'] ?? true,
      createdAt: (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (d['updatedAt'] as Timestamp?)?.toDate(),
    );
  }
}
