import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/constants/app_constants.dart';
import '../../features/products/domain/entities/product_entity.dart';
import '../../services/providers.dart';

final productsProvider = FutureProvider.autoDispose<List<ProductEntity>>((ref) {
  return ref.watch(productServiceProvider).getProducts();
});

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider);
    final cart = ref.watch(cartProvider);

    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: [
          _ProductsTab(userName: user?.fullName ?? 'Guest'),
          _CartTab(),
          _ProfileTab(user: user),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(
            icon: Badge(isLabelVisible: cart.isNotEmpty, label: Text('${cart.length}'), child: const Icon(Icons.shopping_cart_outlined)),
            selectedIcon: const Icon(Icons.shopping_cart),
            label: 'Cart',
          ),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class _ProductsTab extends ConsumerWidget {
  final String userName;
  const _ProductsTab({required this.userName});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productsAsync = ref.watch(productsProvider);

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          floating: true,
          title: const Text(AppConstants.appName),
          actions: [
            if (ref.watch(currentUserProvider)?.isSeller == true ||
                ref.watch(currentUserProvider)?.isSuperAdmin == true)
              IconButton(
                icon: const Icon(Icons.storefront),
                onPressed: () => context.push('/seller'),
              ),
          ],
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Text('Hello, $userName 👋',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          ),
        ),
        productsAsync.when(
          loading: () => const SliverFillRemaining(child: Center(child: CircularProgressIndicator())),
          error: (e, _) => SliverFillRemaining(
            child: Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('Could not load products', style: TextStyle(color: Colors.grey.shade600)),
                const SizedBox(height: 8),
                Text('$e', style: const TextStyle(fontSize: 12), textAlign: TextAlign.center),
                TextButton(onPressed: () => ref.invalidate(productsProvider), child: const Text('Retry')),
              ]),
            ),
          ),
          data: (products) {
            if (products.isEmpty) {
              return SliverFillRemaining(
                child: Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.inventory_2_outlined, size: 64, color: Colors.grey.shade400),
                    const SizedBox(height: 12),
                    const Text('No products yet'),
                    const SizedBox(height: 8),
                    Text('Sellers can add products from Seller Dashboard', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                  ]),
                ),
              );
            }
            return SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.68,
                ),
                delegate: SliverChildBuilderDelegate(
                  (context, i) => _ProductCard(product: products[i]),
                  childCount: products.length,
                ),
              ),
            );
          },
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 24)),
      ],
    );
  }
}

class _ProductCard extends ConsumerWidget {
  final ProductEntity product;
  const _ProductCard({required this.product});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: InkWell(
        onTap: () {
          ref.read(cartProvider.notifier).add(CartItem(
                productId: product.id,
                name: product.name,
                price: product.effectivePrice,
                quantity: 1,
                sellerId: product.sellerId,
                stock: product.stock,
              ));
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('${product.name} added to cart'),
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 1),
          ));
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                width: double.infinity,
                color: Colors.grey.shade100,
                child: Icon(Icons.image_outlined, size: 48, color: Colors.grey.shade400),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                  const SizedBox(height: 4),
                  if (product.hasDiscount)
                    Text('${AppConstants.currencySymbol} ${product.price.toStringAsFixed(0)}',
                        style: TextStyle(fontSize: 11, color: Colors.grey.shade500, decoration: TextDecoration.lineThrough)),
                  Text('${AppConstants.currencySymbol} ${product.effectivePrice.toStringAsFixed(0)}',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CartTab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cart = ref.watch(cartProvider);
    final subtotal = ref.read(cartProvider.notifier).subtotal;

    return Scaffold(
      appBar: AppBar(title: const Text('My Cart')),
      body: cart.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.shopping_cart_outlined, size: 72, color: Colors.grey.shade400),
              const SizedBox(height: 12),
              const Text('Cart is empty'),
            ]))
          : Column(children: [
              Expanded(
                child: ListView.builder(
                  itemCount: cart.length,
                  itemBuilder: (_, i) {
                    final item = cart[i];
                    return ListTile(
                      title: Text(item.name),
                      subtitle: Text('${AppConstants.currencySymbol} ${item.price.toStringAsFixed(0)} x ${item.quantity}'),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(
                          icon: const Icon(Icons.remove_circle_outline),
                          onPressed: () {
                            if (item.quantity <= 1) {
                              ref.read(cartProvider.notifier).remove(item.productId);
                            } else {
                              ref.read(cartProvider.notifier).updateQty(item.productId, item.quantity - 1);
                            }
                          },
                        ),
                        Text('${item.quantity}'),
                        IconButton(
                          icon: const Icon(Icons.add_circle_outline),
                          onPressed: () => ref.read(cartProvider.notifier).updateQty(item.productId, item.quantity + 1),
                        ),
                      ]),
                    );
                  },
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Text('Subtotal', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      Text('${AppConstants.currencySymbol} ${subtotal.toStringAsFixed(0)}',
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ]),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: () async {
                          final user = ref.read(currentUserProvider);
                          if (user == null) return;
                          final items = cart
                              .map((e) => {
                                    'productId': e.productId,
                                    'productName': e.name,
                                    'unitPrice': e.price,
                                    'quantity': e.quantity,
                                    'sellerId': e.sellerId,
                                  })
                              .toList();
                          try {
                            await ref.read(orderServiceProvider).createOrder(
                                  buyerId: user.id,
                                  buyerName: user.fullName,
                                  items: items,
                                  subtotal: subtotal,
                                );
                            ref.read(cartProvider.notifier).clear();
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: const Text('Order placed successfully'),
                                backgroundColor: Colors.green.shade700,
                              ));
                            }
                          } catch (e) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text('Order failed: $e'),
                                backgroundColor: Colors.red.shade700,
                              ));
                            }
                          }
                        },
                        child: const Text('Place Order'),
                      ),
                    ),
                  ]),
                ),
              ),
            ]),
    );
  }
}

class _ProfileTab extends ConsumerWidget {
  final dynamic user;
  const _ProfileTab({this.user});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            leading: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.primary,
              child: Text(
                (user?.fullName?.isNotEmpty == true) ? user.fullName[0].toUpperCase() : 'U',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(user?.fullName ?? 'User'),
            subtitle: Text(user?.email ?? ''),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text('Sign Out', style: TextStyle(color: Colors.red)),
            onTap: () async {
              await ref.read(authServiceProvider).signOut();
              if (context.mounted) context.go('/login');
            },
          ),
        ],
      ),
    );
  }
}
