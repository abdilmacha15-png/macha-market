import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants/app_constants.dart';
import '../features/products/domain/entities/product_entity.dart';

class ProductService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference get _col => _db.collection(AppConstants.productsCollection);

  Future<List<ProductEntity>> getProducts({
    String? category,
    String? sellerId,
    String? search,
  }) async {
    Query q = _col.where('isActive', isEqualTo: true);
    if (sellerId != null) q = q.where('sellerId', isEqualTo: sellerId);
    if (category != null && category.isNotEmpty) {
      q = q.where('category', isEqualTo: category);
    }
    final snap = await q.orderBy('createdAt', descending: true).limit(50).get();
    var list = snap.docs.map((d) => _fromDoc(d)).toList();
    if (search != null && search.isNotEmpty) {
      final s = search.toLowerCase();
      list = list.where((p) => p.name.toLowerCase().contains(s)).toList();
    }
    return list;
  }

  Future<ProductEntity?> getById(String id) async {
    final doc = await _col.doc(id).get();
    if (!doc.exists) return null;
    return _fromDoc(doc);
  }

  Future<String> createProduct(ProductEntity product) async {
    final ref = await _col.add({
      ...product.toMap(),
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> updateProduct(String id, Map<String, dynamic> data) async {
    await _col.doc(id).update(data);
  }

  Future<void> deleteProduct(String id) async {
    await _col.doc(id).update({'isActive': false});
  }

  ProductEntity _fromDoc(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return ProductEntity(
      id: doc.id,
      sellerId: d['sellerId'] ?? '',
      sellerName: d['sellerName'] ?? '',
      name: d['name'] ?? '',
      description: d['description'] ?? '',
      price: (d['price'] as num?)?.toDouble() ?? 0,
      discountPrice: (d['discountPrice'] as num?)?.toDouble(),
      stock: d['stock'] ?? 0,
      category: d['category'] ?? 'General',
      images: List<String>.from(d['images'] ?? []),
      rating: (d['rating'] as num?)?.toDouble() ?? 0,
      reviewCount: d['reviewCount'] ?? 0,
      isActive: d['isActive'] ?? true,
      createdAt: (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}
