import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../features/auth/domain/entities/user_entity.dart';
import 'auth_service.dart';
import 'product_service.dart';
import 'order_service.dart';

final authServiceProvider = Provider((ref) => AuthService());
final productServiceProvider = Provider((ref) => ProductService());
final orderServiceProvider = Provider((ref) => OrderService());

final authStateProvider = StreamProvider<UserEntity?>((ref) {
  return ref.watch(authServiceProvider).userStream();
});

final currentUserProvider = Provider<UserEntity?>((ref) {
  return ref.watch(authStateProvider).valueOrNull;
});

// Cart state
class CartItem {
  final String productId;
  final String name;
  final String? image;
  final double price;
  final int quantity;
  final String sellerId;
  final int stock;

  CartItem({
    required this.productId,
    required this.name,
    this.image,
    required this.price,
    required this.quantity,
    required this.sellerId,
    required this.stock,
  });

  double get total => price * quantity;

  CartItem copyWith({int? quantity}) => CartItem(
        productId: productId,
        name: name,
        image: image,
        price: price,
        quantity: quantity ?? this.quantity,
        sellerId: sellerId,
        stock: stock,
      );
}

class CartNotifier extends StateNotifier<List<CartItem>> {
  CartNotifier() : super([]);

  void add(CartItem item) {
    final i = state.indexWhere((e) => e.productId == item.productId);
    if (i >= 0) {
      final updated = [...state];
      final q = updated[i].quantity + item.quantity;
      updated[i] = updated[i].copyWith(quantity: q.clamp(1, item.stock));
      state = updated;
    } else {
      state = [...state, item];
    }
  }

  void remove(String productId) {
    state = state.where((e) => e.productId != productId).toList();
  }

  void updateQty(String productId, int qty) {
    state = [
      for (final e in state)
        if (e.productId == productId)
          e.copyWith(quantity: qty.clamp(1, e.stock))
        else
          e
    ];
  }

  void clear() => state = [];

  double get subtotal => state.fold(0, (s, e) => s + e.total);
  int get count => state.fold(0, (s, e) => s + e.quantity);
}

final cartProvider = StateNotifierProvider<CartNotifier, List<CartItem>>((ref) {
  return CartNotifier();
});
