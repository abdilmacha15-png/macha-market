import 'package:cloud_firestore/cloud_firestore.dart';
import '../core/constants/app_constants.dart';
import '../core/utils/commission_helper.dart';

class OrderService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<String> createOrder({
    required String buyerId,
    required String buyerName,
    required List<Map<String, dynamic>> items,
    required double subtotal,
    String? shippingAddress,
    String? paymentMethod,
  }) async {
    final commission = CommissionHelper.calculateCommission(subtotal);
    final sellerAmount = CommissionHelper.calculateSellerPayout(subtotal);

    final ref = await _db.collection(AppConstants.ordersCollection).add({
      'buyerId': buyerId,
      'buyerName': buyerName,
      'items': items,
      'subtotal': subtotal,
      'commissionAmount': commission,
      'sellerAmount': sellerAmount,
      'total': subtotal,
      'status': AppConstants.orderPending,
      'shippingAddress': shippingAddress,
      'paymentMethod': paymentMethod ?? 'cash',
      'paymentStatus': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> updateStatus(String orderId, String status) async {
    final data = <String, dynamic>{
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    };
    if (status == AppConstants.orderDelivered ||
        status == AppConstants.orderCompleted) {
      data['deliveredAt'] = FieldValue.serverTimestamp();
      // Credit seller wallet (95%) when delivered
      final order = await _db.collection(AppConstants.ordersCollection).doc(orderId).get();
      if (order.exists) {
        final d = order.data()!;
        final sellerAmount = (d['sellerAmount'] as num?)?.toDouble() ?? 0;
        final items = List<Map<String, dynamic>>.from(d['items'] ?? []);
        // Group by seller and credit
        final sellerIds = items.map((e) => e['sellerId'] as String).toSet();
        for (final sid in sellerIds) {
          final walletRef = _db.collection(AppConstants.walletsCollection).doc(sid);
          await _db.runTransaction((tx) async {
            final w = await tx.get(walletRef);
            if (w.exists) {
              final bal = (w.data()!['balance'] as num?)?.toDouble() ?? 0;
              final earned = (w.data()!['totalEarned'] as num?)?.toDouble() ?? 0;
              tx.update(walletRef, {
                'balance': bal + sellerAmount,
                'totalEarned': earned + sellerAmount,
                'updatedAt': FieldValue.serverTimestamp(),
              });
            }
          });
        }
      }
    }
    await _db.collection(AppConstants.ordersCollection).doc(orderId).update(data);
  }

  Stream<QuerySnapshot> ordersForBuyer(String buyerId) {
    return _db
        .collection(AppConstants.ordersCollection)
        .where('buyerId', isEqualTo: buyerId)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot> allOrders() {
    return _db
        .collection(AppConstants.ordersCollection)
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots();
  }
}
