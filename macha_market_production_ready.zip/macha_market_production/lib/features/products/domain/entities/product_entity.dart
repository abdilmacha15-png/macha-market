import 'package:equatable/equatable.dart';

class ProductEntity extends Equatable {
  final String id;
  final String sellerId;
  final String sellerName;
  final String name;
  final String description;
  final double price;
  final double? discountPrice;
  final int stock;
  final String category;
  final List<String> images;
  final double rating;
  final int reviewCount;
  final bool isActive;
  final DateTime createdAt;

  const ProductEntity({
    required this.id,
    required this.sellerId,
    required this.sellerName,
    required this.name,
    required this.description,
    required this.price,
    this.discountPrice,
    required this.stock,
    required this.category,
    this.images = const [],
    this.rating = 0,
    this.reviewCount = 0,
    this.isActive = true,
    required this.createdAt,
  });

  double get effectivePrice => discountPrice ?? price;
  bool get hasDiscount => discountPrice != null && discountPrice! < price;
  bool get inStock => stock > 0;

  Map<String, dynamic> toMap() => {
        'sellerId': sellerId,
        'sellerName': sellerName,
        'name': name,
        'description': description,
        'price': price,
        'discountPrice': discountPrice,
        'stock': stock,
        'category': category,
        'images': images,
        'rating': rating,
        'reviewCount': reviewCount,
        'isActive': isActive,
        'createdAt': createdAt.toIso8601String(),
      };

  @override
  List<Object?> get props => [id, sellerId, name, price, stock, category];
}
