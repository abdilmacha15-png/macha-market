# Macha Market

Production Flutter marketplace with Firebase Auth, Firestore, Riverpod, GoRouter.

## Firebase (required once)

1. Open https://console.firebase.google.com → project **macha-market**
2. Authentication → Sign-in method → **Email/Password** → Enable → Save
3. Confirm `android/app/google-services.json` is present
4. Confirm `lib/firebase_options.dart` uses real API key (not Dummy)

## Run

```bash
flutter pub get
flutter run
```

## Build APK

```bash
flutter create . --platforms=android
flutter build apk --release
```

Package: `com.machamarket.macha_market`
