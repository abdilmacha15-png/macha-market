# Macha Market

Professional marketplace (Buyer + Seller) — Blue/Orange brand UI.

## Fix "Imeshindikana kupakia" (products fail to load)

1. **Deploy Firestore rules** (products must be readable):
   ```bash
   firebase deploy --only firestore:rules,storage
   ```
   Or paste `firestore.rules` / `storage.rules` in Firebase Console.

2. Product query no longer needs a composite index (client-side filter).

3. Add a product from **Seller Dashboard** so Buyer Home has data.

## Run
```bash
flutter pub get
flutter run
flutter build apk --release
```

## Brand
- Primary Blue `#004EFD`
- Accent Orange `#FF7A00`
- Package: `com.machamarket.macha_market`

## Features
Auth · Buyer Home · Categories · Cart · Orders · Seller Dashboard ·
Products + image upload · Wallet · 5% commission · Admin
