import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/commission_helper.dart';
import '../../features/products/domain/entities/product_entity.dart';
import '../../services/providers.dart';

const _categories = [
  'Electronics', 'Fashion', 'Home', 'Sports', 'Books', 'Beauty', 'Food', 'General',
];
const _conditions = ['new', 'used', 'refurbished'];

final sellerProductsProvider = StreamProvider.autoDispose<List<ProductEntity>>((ref) {
  final user = ref.watch(currentUserProvider);
  if (user == null) return Stream.value([]);
  return ref.watch(productServiceProvider).watchSellerProducts(user.id);
});

class SellerPage extends ConsumerStatefulWidget {
  const SellerPage({super.key});
  @override
  ConsumerState<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends ConsumerState<SellerPage> {
  int _tab = 0;
  final _picker = ImagePicker();

  Future<void> _openProductForm({ProductEntity? existing}) async {
    final user = ref.read(currentUserProvider);
    if (user == null) return;

    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final priceCtrl = TextEditingController(text: existing != null ? existing.price.toStringAsFixed(0) : '');
    final discountCtrl = TextEditingController(
        text: existing?.discountPrice != null ? existing!.discountPrice!.toStringAsFixed(0) : '');
    final stockCtrl = TextEditingController(text: existing != null ? '${existing.stock}' : '1');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    final locationCtrl = TextEditingController(text: existing?.location ?? '');
    String category = existing?.category ?? 'General';
    String condition = existing?.condition ?? 'new';
    File? localImage;
    String? existingImage = existing?.images.isNotEmpty == true ? existing!.images.first : null;
    bool saving = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModal) {
          Future<void> pick() async {
            final x = await _picker.pickImage(source: ImageSource.gallery, maxWidth: 1200, imageQuality: 85);
            if (x != null) setModal(() { localImage = File(x.path); existingImage = null; });
          }

          Future<void> save() async {
            final name = nameCtrl.text.trim();
            final price = double.tryParse(priceCtrl.text.trim());
            final stock = int.tryParse(stockCtrl.text.trim()) ?? 0;
            if (name.isEmpty || price == null || price <= 0) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Name and valid price required')));
              return;
            }
            setModal(() => saving = true);
            try {
              final svc = ref.read(productServiceProvider);
              var images = existing?.images ?? <String>[];
              if (localImage != null) {
                final url = await svc.uploadProductImage(localImage!, user.id);
                images = [url];
              }
              final discount = double.tryParse(discountCtrl.text.trim());
              if (existing == null) {
                await svc.createProduct(
                  sellerId: user.id,
                  sellerName: user.shopName ?? user.fullName,
                  name: name,
                  description: descCtrl.text.trim(),
                  price: price,
                  discountPrice: discount,
                  stock: stock,
                  category: category,
                  images: images,
                  location: locationCtrl.text.trim(),
                  condition: condition,
                );
              } else {
                await svc.updateProduct(existing.id, {
                  'name': name,
                  'description': descCtrl.text.trim(),
                  'price': price,
                  'discountPrice': discount,
                  'stock': stock,
                  'category': category,
                  'images': images,
                  'location': locationCtrl.text.trim(),
                  'condition': condition,
                  'isActive': true,
                  'status': 'active',
                });
              }
              ref.invalidate(productsProvider);
              if (ctx.mounted) Navigator.pop(ctx);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(existing == null ? 'Product added' : 'Product updated'),
                  backgroundColor: Colors.green.shade700,
                ));
              }
            } catch (e) {
              setModal(() => saving = false);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'), backgroundColor: Colors.red));
              }
            }
          }

          return Padding(
            padding: EdgeInsets.only(left: 20, right: 20, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text(existing == null ? 'Add Product' : 'Edit Product',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: saving ? null : pick,
                  child: Container(
                    height: 130,
                    decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade300)),
                    clipBehavior: Clip.antiAlias,
                    child: localImage != null
                        ? Image.file(localImage!, fit: BoxFit.cover)
                        : existingImage != null
                            ? CachedNetworkImage(imageUrl: existingImage!, fit: BoxFit.cover)
                            : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                Icon(Icons.add_a_photo_outlined, size: 36, color: Colors.grey.shade500),
                                const SizedBox(height: 6),
                                Text('Upload product image', style: TextStyle(color: Colors.grey.shade600)),
                              ]),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Product name', prefixIcon: Icon(Icons.shopping_bag_outlined))),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: TextField(controller: priceCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price (TZS)'))),
                  const SizedBox(width: 10),
                  Expanded(child: TextField(controller: discountCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Discount (optional)'))),
                ]),
                const SizedBox(height: 10),
                TextField(controller: stockCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stock quantity', prefixIcon: Icon(Icons.inventory_2_outlined))),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: category,
                  decoration: const InputDecoration(labelText: 'Category'),
                  items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: saving ? null : (v) { if (v != null) setModal(() => category = v); },
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: condition,
                  decoration: const InputDecoration(labelText: 'Condition'),
                  items: _conditions.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                  onChanged: saving ? null : (v) { if (v != null) setModal(() => condition = v); },
                ),
                const SizedBox(height: 10),
                TextField(controller: locationCtrl, decoration: const InputDecoration(labelText: 'Location', prefixIcon: Icon(Icons.location_on_outlined))),
                const SizedBox(height: 10),
                TextField(controller: descCtrl, maxLines: 3, decoration: const InputDecoration(labelText: 'Description', alignLabelWithHint: true)),
                const SizedBox(height: 16),
                SizedBox(
                  height: 48,
                  child: ElevatedButton(
                    onPressed: saving ? null : save,
                    child: saving
                        ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                        : Text(existing == null ? 'Publish Product' : 'Save Changes'),
                  ),
                ),
              ]),
            ),
          );
        },
      ),
    );
  }

  Future<void> _delete(ProductEntity p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete product?'),
        content: Text('"${p.name}" will be removed from the marketplace.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(c, true), style: TextButton.styleFrom(foregroundColor: Colors.red), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    await ref.read(productServiceProvider).deleteProduct(p.id);
    ref.invalidate(productsProvider);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('"${p.name}" deleted')));
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider);
    final productsAsync = ref.watch(sellerProductsProvider);
    final products = productsAsync.valueOrNull ?? [];
    final active = products.where((p) => p.isActive).length;

    final pages = [
      _DashboardTab(
        userName: user?.shopName ?? user?.fullName ?? 'Seller',
        totalProducts: products.length,
        activeProducts: active,
        onAdd: () => _openProductForm(),
        onViewProducts: () => setState(() => _tab = 1),
      ),
      _ProductsTab(
        productsAsync: productsAsync,
        onAdd: () => _openProductForm(),
        onEdit: (p) => _openProductForm(existing: p),
        onDelete: _delete,
        onRefresh: () { ref.invalidate(sellerProductsProvider); ref.invalidate(productsProvider); },
      ),
      _SellerOrdersTab(sellerId: user?.id ?? ''),
      _SellerProfileTab(user: user),
    ];

    return Scaffold(
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Products'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Orders'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
      floatingActionButton: _tab == 1
          ? FloatingActionButton.extended(onPressed: () => _openProductForm(), icon: const Icon(Icons.add), label: const Text('Add Product'))
          : null,
    );
  }
}

class _DashboardTab extends ConsumerWidget {
  final String userName;
  final int totalProducts;
  final int activeProducts;
  final VoidCallback onAdd;
  final VoidCallback onViewProducts;
  const _DashboardTab({required this.userName, required this.totalProducts, required this.activeProducts, required this.onAdd, required this.onViewProducts});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    return CustomScrollView(slivers: [
      SliverAppBar(
        floating: true,
        title: const Text('Seller Dashboard'),
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => context.go('/home')),
      ),
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Habari, $userName 👋', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('You keep ${100 - CommissionHelper.commissionPercent.toInt()}% · Platform ${CommissionHelper.commissionPercent.toInt()}%',
                style: TextStyle(color: Colors.grey.shade600)),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: _StatCard(title: 'Products', value: '$totalProducts', icon: Icons.inventory_2, color: AppTheme.primaryColor)),
              const SizedBox(width: 12),
              Expanded(child: _StatCard(title: 'Active', value: '$activeProducts', icon: Icons.check_circle, color: Colors.green)),
            ]),
            const SizedBox(height: 12),
            FutureBuilder(
              future: user == null ? null : ref.read(orderServiceProvider).sellerOrderStats(user.id),
              builder: (context, snap) {
                final orders = snap.data?['orders'] ?? 0;
                final sales = (snap.data?['sales'] as num?)?.toDouble() ?? 0;
                return Row(children: [
                  Expanded(child: _StatCard(title: 'Orders', value: '$orders', icon: Icons.receipt_long, color: Colors.orange)),
                  const SizedBox(width: 12),
                  Expanded(child: _StatCard(title: 'Earnings', value: '${AppConstants.currencySymbol} ${sales.toStringAsFixed(0)}', icon: Icons.payments, color: Colors.purple)),
                ]);
              },
            ),
            const SizedBox(height: 12),
            StreamBuilder(
              stream: user == null ? null : ref.read(walletServiceProvider).walletStream(user.id),
              builder: (context, snap) {
                final bal = snap.hasData && snap.data!.exists
                    ? ((snap.data!.data()?['balance'] as num?)?.toDouble() ?? 0)
                    : 0.0;
                return _StatCard(title: 'Wallet Balance', value: '${AppConstants.currencySymbol} ${bal.toStringAsFixed(0)}', icon: Icons.account_balance_wallet, color: Colors.blue);
              },
            ),
            const SizedBox(height: 24),
            Text('Quick Actions', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ListTile(leading: const CircleAvatar(child: Icon(Icons.add)), title: const Text('Add Product'), trailing: const Icon(Icons.chevron_right), onTap: onAdd),
            ListTile(leading: const CircleAvatar(child: Icon(Icons.list_alt)), title: const Text('Manage Products'), trailing: const Icon(Icons.chevron_right), onTap: onViewProducts),
            ListTile(leading: const CircleAvatar(child: Icon(Icons.account_balance_wallet)), title: const Text('Wallet'), trailing: const Icon(Icons.chevron_right), onTap: () => context.push('/wallet')),
          ]),
        ),
      ),
    ]);
  }
}

class _StatCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  final Color color;
  const _StatCard({required this.title, required this.value, required this.icon, required this.color});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 10),
          Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
          Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
        ]),
      ),
    );
  }
}

class _ProductsTab extends StatelessWidget {
  final AsyncValue<List<ProductEntity>> productsAsync;
  final VoidCallback onAdd;
  final void Function(ProductEntity) onEdit;
  final void Function(ProductEntity) onDelete;
  final VoidCallback onRefresh;
  const _ProductsTab({required this.productsAsync, required this.onAdd, required this.onEdit, required this.onDelete, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Products'), automaticallyImplyLeading: false),
      body: RefreshIndicator(
        onRefresh: () async => onRefresh(),
        child: productsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('$e')),
          data: (list) {
            final active = list.where((p) => p.isActive).toList();
            if (active.isEmpty) {
              return ListView(children: [
                const SizedBox(height: 80),
                Icon(Icons.inventory_2_outlined, size: 72, color: Colors.grey.shade400),
                const SizedBox(height: 12),
                const Center(child: Text('No products yet')),
                const SizedBox(height: 16),
                Center(child: ElevatedButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: const Text('Add Product'))),
              ]);
            }
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: active.length,
              itemBuilder: (_, i) {
                final p = active[i];
                final img = p.images.isNotEmpty ? p.images.first : null;
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: SizedBox(
                        width: 56, height: 56,
                        child: img != null
                            ? CachedNetworkImage(imageUrl: img, fit: BoxFit.cover)
                            : Container(color: Colors.grey.shade200, child: const Icon(Icons.image)),
                      ),
                    ),
                    title: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text('${AppConstants.currencySymbol} ${p.price.toStringAsFixed(0)} · Stock ${p.stock} · ${p.category}'),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) { if (v == 'edit') onEdit(p); if (v == 'delete') onDelete(p); },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Edit')),
                        PopupMenuItem(value: 'delete', child: Text('Delete', style: TextStyle(color: Colors.red))),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _SellerOrdersTab extends ConsumerWidget {
  final String sellerId;
  const _SellerOrdersTab({required this.sellerId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (sellerId.isEmpty) return const Center(child: Text('Not signed in'));
    final stream = ref.watch(orderServiceProvider).ordersForSeller(sellerId);
    return Scaffold(
      appBar: AppBar(title: const Text('Orders'), automaticallyImplyLeading: false),
      body: StreamBuilder(
        stream: stream,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snap.data ?? [];
          if (docs.isEmpty) {
            return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.receipt_long_outlined, size: 64, color: Colors.grey.shade400),
              const SizedBox(height: 12),
              const Text('No orders yet'),
            ]));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: docs.length,
            itemBuilder: (_, i) {
              final d = docs[i].data();
              final id = docs[i].id;
              final status = d['status'] ?? 'pending';
              final total = (d['total'] as num?)?.toDouble() ?? 0;
              return Card(
                child: ListTile(
                  title: Text('Order ${id.substring(0, 8)}…'),
                  subtitle: Text('${d['buyerName'] ?? ''} · ${AppConstants.currencySymbol} ${total.toStringAsFixed(0)}\n$status'),
                  isThreeLine: true,
                  trailing: PopupMenuButton<String>(
                    onSelected: (s) => ref.read(orderServiceProvider).updateStatus(id, s),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'accepted', child: Text('Accept')),
                      PopupMenuItem(value: 'processing', child: Text('Processing')),
                      PopupMenuItem(value: 'shipped', child: Text('Shipped')),
                      PopupMenuItem(value: 'delivered', child: Text('Delivered')),
                      PopupMenuItem(value: 'cancelled', child: Text('Cancel')),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _SellerProfileTab extends ConsumerWidget {
  final dynamic user;
  const _SellerProfileTab({this.user});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Seller Profile'), automaticallyImplyLeading: false),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        ListTile(
          leading: CircleAvatar(
            backgroundColor: Theme.of(context).colorScheme.primary,
            child: Text((user?.fullName?.isNotEmpty == true) ? user.fullName[0].toUpperCase() : 'S', style: const TextStyle(color: Colors.white)),
          ),
          title: Text(user?.fullName ?? 'Seller'),
          subtitle: Text(user?.email ?? ''),
        ),
        ListTile(leading: const Icon(Icons.badge), title: const Text('Role'), subtitle: Text((user?.role ?? 'seller').toString().toUpperCase())),
        ListTile(leading: const Icon(Icons.home_outlined), title: const Text('Buyer Home'), trailing: const Icon(Icons.chevron_right), onTap: () => context.go('/home')),
        ListTile(leading: const Icon(Icons.account_balance_wallet_outlined), title: const Text('Wallet'), trailing: const Icon(Icons.chevron_right), onTap: () => context.push('/wallet')),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: const Text('Sign Out', style: TextStyle(color: Colors.red)),
          onTap: () async {
            await ref.read(authServiceProvider).signOut();
            if (context.mounted) context.go('/login');
          },
        ),
      ]),
    );
  }
}
