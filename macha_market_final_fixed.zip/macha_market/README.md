# Macha Market

Professional Flutter marketplace (Buyer + Seller + Admin) with Firebase Auth/Firestore and Cloudinary image uploads.

## Package

`com.machamarket.macha_market`

## Features

- Email/password authentication
- Buyer home, categories, cart, orders, profile
- Seller dashboard: add/edit/delete products, orders, wallet
- 5% platform / 95% seller commission
- Cloudinary product image upload (unsigned preset)
- Firestore product feed

## Image uploads (Cloudinary)

- Cloud name: `qijmuww5`
- Upload preset: `Macha_present` (must be **Unsigned** in Cloudinary dashboard)
- Invalid/missing image URLs are handled gracefully (no crash)

## Setup

```bash
cd macha_market
flutter pub get
flutter run
```

Ensure `android/app/google-services.json` matches your Firebase project.

## Android

- minSdkVersion: **23** (required by firebase_auth)
- compileSdk / targetSdk: 34
- Java 17

## CI

`.github/workflows/build_apk.yml` builds a release APK and uploads it as an artifact.

## Firestore rules

Deploy `firestore.rules` and `firestore.indexes.json` from the project root.
